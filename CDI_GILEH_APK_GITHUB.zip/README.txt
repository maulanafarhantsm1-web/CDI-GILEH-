CDI GILEH Android WebView
==========================

This APK is a native Android WebView wrapper for the ESP8266 CDI_GILEH dashboard.

When the phone is connected to the CDI_GILEH ESP8266 access point, the app opens:
http://192.168.4.1/

No Android Studio is required.

GitHub:
1. Create a new repository.
2. Upload ALL files/folders from this ZIP to the repository root.
3. Use the main branch.
4. Open Actions -> "Build CDI GILEH APK".
5. Wait for the green check.
6. Open the workflow run and download the "CDI_GILEH-APK" artifact.
